# TP2 — Stack multi-services avec Docker Compose

## Objectif

Écrire le `docker-compose.yml` qui orchestre une stack `frontend + API Node.js + PostgreSQL + Adminer`, avec persistance des données et gestion des secrets via `.env`.

## Contenu du dossier

```
tp2/
├── api/
│   ├── index.js          # API Node.js (fourni)
│   ├── package.json      # Dépendances (fourni)
│   └── Dockerfile        # Fourni
├── frontend/
│   ├── index.html        # Interface web (fourni)
│   └── Dockerfile        # Fourni
├── docker-compose.yml    # Créé — 4 services
├── .env                  # Secrets locaux (ne pas commiter)
├── .env.example          # Template sans valeurs sensibles
└── RAPPORT_TP2.md        # Explication des 3 étapes
```

## Lancer la stack

```bash
# 1. Copier et remplir le fichier .env
cp .env.example .env
# Éditer .env : renseigner DB_PASSWORD

# 2. Démarrer
docker compose up --build
```

## URLs

| Service | URL |
|---------|-----|
| Frontend | http://localhost:8080 |
| API (healthcheck) | http://localhost:3000/health |
| Adminer | http://localhost:8081 |

## Connexion Adminer

- Système : `PostgreSQL`
- Serveur : `database`
- Utilisateur : valeur de `DB_USER` (défaut : `tp2user`)
- Mot de passe : valeur de `DB_PASSWORD`
- Base : valeur de `DB_NAME` (défaut : `tp2db`)

## Vérifications

```bash
# Persistance des données
docker compose down
docker compose up -d
# → Les messages sont toujours là sur http://localhost:8080

# Pas de secrets en clair dans le Compose
grep -i password docker-compose.yml
# → uniquement ${DB_PASSWORD}, jamais la vraie valeur
```

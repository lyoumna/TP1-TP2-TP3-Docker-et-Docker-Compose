# TP2 — Docker Compose : stack multi-services

## Structure du projet

```
tp2/
├── api/
│   ├── index.js        # API Node.js (fourni)
│   ├── package.json    # Dépendances (fourni)
│   └── Dockerfile      # Fourni
├── frontend/
│   ├── index.html      # Interface web (fourni)
│   └── Dockerfile      # Fourni
├── docker-compose.yml  # ← créé
├── .env                # ← créé (secrets locaux, ne pas commiter)
└── .env.example        # ← créé (template sans valeurs sensibles)
```

---

## Étape 1 — Docker Compose (3 services)

### `docker-compose.yml`

```yaml
version: "3.9"

services:

  database:
    image: postgres:16-alpine
    environment:
      POSTGRES_DB:       ${DB_NAME}
      POSTGRES_USER:     ${DB_USER}
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    volumes:
      - db_data:/var/lib/postgresql/data
    # Pas de ports: → database non exposée sur l'hôte
    networks:
      - backend_net
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${DB_USER} -d ${DB_NAME}"]
      interval: 5s
      timeout: 5s
      retries: 10

  api:
    build: ./api
    environment:
      DB_HOST:     database
      DB_PORT:     5432
      DB_NAME:     ${DB_NAME}
      DB_USER:     ${DB_USER}
      DB_PASSWORD: ${DB_PASSWORD}
      PORT:        3000
    ports:
      - "3000:3000"
    depends_on:
      database:
        condition: service_healthy
    restart: on-failure
    networks:
      - backend_net

  frontend:
    build: ./frontend
    ports:
      - "8080:80"
    networks:
      - backend_net

  adminer:
    image: adminer:latest
    environment:
      ADMINER_DEFAULT_SERVER: database
    ports:
      - "8081:8080"
    depends_on:
      - database
    networks:
      - backend_net

volumes:
  db_data:

networks:
  backend_net:
```

### Vérification étape 1

```bash
docker compose up --build
# http://localhost:8080 → page frontend ✅
# http://localhost:3000/health → {"status":"ok"} ✅
# Envoyer un message → il s'affiche ✅
```

---

## Étape 2 — Volumes + `.env`

### 2a — Volume nommé pour PostgreSQL

Le volume `db_data` est déclaré dans `docker-compose.yml` :

```yaml
services:
  database:
    volumes:
      - db_data:/var/lib/postgresql/data

volumes:
  db_data:
```

`docker compose down` sans `-v` ne supprime pas le volume → données persistantes.

```bash
# Test de persistance
docker compose down
docker compose up -d
# http://localhost:8080 → messages toujours présents ✅
```

### 2b — Fichier `.env` pour les secrets

**Fichier `.env`** (local, ne pas commiter) :

```env
DB_NAME=tp2db
DB_USER=tp2user
DB_PASSWORD=change-moi-en-local
```

**Fichier `.env.example`** (commité, sans valeurs sensibles) :

```env
DB_NAME=tp2db
DB_USER=tp2user
DB_PASSWORD=
```

Vérification qu'aucun mot de passe n'est en clair dans `docker-compose.yml` :

```bash
grep -i password docker-compose.yml
# POSTGRES_PASSWORD: ${DB_PASSWORD}   ← référence, pas la valeur ✅
# DB_PASSWORD: ${DB_PASSWORD}         ← idem ✅
```

---

## Étape 3 — Service Adminer

Adminer est ajouté comme 4e service :

```yaml
  adminer:
    image: adminer:latest
    environment:
      ADMINER_DEFAULT_SERVER: database   # pré-remplit le champ serveur
    ports:
      - "8081:8080"
    depends_on:
      - database
    networks:
      - backend_net
```

### Connexion Adminer

| Champ | Valeur |
|-------|--------|
| Système | PostgreSQL |
| Serveur | `database` (résolution DNS Docker interne) |
| Utilisateur | valeur de `DB_USER` |
| Mot de passe | valeur de `DB_PASSWORD` |
| Base de données | valeur de `DB_NAME` |

```bash
# http://localhost:8081 → interface Adminer ✅
# Table "messages" visible avec les données ✅
```

---

## Récapitulatif des critères de réussite

| Critère | Statut | Vérification |
|---------|--------|--------------|
| Frontend accessible | ✅ | `http://localhost:8080` affiche la page |
| API accessible | ✅ | `http://localhost:3000/health` → `{"status":"ok"}` |
| Communication API - BDD | ✅ | Message envoyé → visible dans la liste |
| BDD non exposée | ✅ | Aucun `ports:` sur le service `database` |
| Adminer accessible | ✅ | `http://localhost:8081` affiche l'interface |
| Adminer connecté à la BDD | ✅ | Table `messages` visible |
| Données persistantes | ✅ | Survivent à `docker compose down` puis `up -d` |
| Pas de secrets en dur | ✅ | `grep -i password docker-compose.yml` → références `${...}` uniquement |

---

## Notes techniques

**Pourquoi `depends_on` avec `condition: service_healthy` ?**

`depends_on` seul démarre les containers dans le bon ordre, mais PostgreSQL n'est pas forcément prêt à accepter des connexions quand son container est « Up ». Le `healthcheck` avec `pg_isready` garantit que l'API ne démarre que lorsque la base de données est réellement opérationnelle.

**Réseau Docker interne**

Le frontend s'exécute dans le navigateur de l'utilisateur, pas dans Docker. Il appelle donc `http://localhost:3000` (port exposé). En revanche, l'API contacte PostgreSQL via le nom de service `database` (résolution DNS Docker interne, port 5432), sans passer par l'hôte.

# TP1 — Réparer une image Docker cassée

## Niveau 1 — Analyse du Dockerfile original

### Dockerfile original

```dockerfile
FROM node:18

WORKDIR /app

ENV API_KEY=sk-prod-abc123xyz456
ENV DB_PASSWORD=supersecret123
ENV DB_HOST=prod-db.monapp.com

COPY . .

RUN npm install

RUN npm run build

RUN apt-get update && apt-get install -y \
    curl wget vim git htop net-tools

EXPOSE 3000

CMD ["node", "dist/index.js"]
```

### Tableau de diagnostic

| Ligne(s) | Problème observé | Conséquence en production | Correction envisagée |
|----------|-----------------|--------------------------|----------------------|
| `FROM node:18` | Image de base complète (Debian), taille ~350 MB | Image finale très lourde, surface d'attaque inutilement grande | Utiliser `node:18-alpine` (~50 MB) |
| `ENV API_KEY=...` / `ENV DB_PASSWORD=...` / `ENV DB_HOST=...` | Secrets et URLs de production codés en dur dans l'image | Les secrets sont visibles dans `docker inspect` et dans l'historique de chaque layer — fuite de données garantie si l'image est partagée | Supprimer ces `ENV` du Dockerfile ; les injecter via `docker run -e` ou un fichier `.env` au runtime |
| `COPY . .` avant `RUN npm install` | Tout le code est copié avant l'installation des dépendances | Le cache Docker est invalidé à chaque modification de fichier source, même une ligne de code → `npm install` re-tourne entièrement à chaque build | Copier `package*.json` seul, faire `npm install`, puis copier le code |
| `RUN npm install` | Installe aussi les `devDependencies` (`nodemon`) | Image plus lourde, outils de développement présents en production | Utiliser `npm install --omit=dev` |
| `RUN npm run build` + `CMD ["node", "dist/index.js"]` | Le script `build` fait `cp /app/index.js dist/index.js` (inutile) et la CMD pointe vers `dist/index.js` qui n'est qu'une copie | Étape de build inutile qui alourdit l'image et complique la maintenance | Supprimer le `RUN npm run build` ; utiliser directement `CMD ["node", "index.js"]` |
| `RUN apt-get install -y curl wget vim git htop net-tools` | Installation d'outils système inutiles en production | Image beaucoup plus lourde ; outils comme `vim`, `git`, `wget` constituent des vecteurs d'attaque si le container est compromis | Supprimer entièrement ce bloc |
| *(absent)* | Pas d'utilisateur non-root défini | Le processus Node tourne en `root` dans le container — toute faille d'exécution donne les droits root | Ajouter `USER node` avant `CMD` |
| *(absent)* | Pas de fichier `.dockerignore` | `node_modules/`, `.env`, `.git/` et les logs sont copiés dans le contexte de build → image lourde, secrets potentiellement inclus | Créer un `.dockerignore` complet |

> **Total : 8 problèmes identifiés** (minimum demandé : 5 ✅)

---

## Niveau 2 — Dockerfile corrigé

```dockerfile
# ✅ Image légère alpine (~50 MB) au lieu de node:18 Debian (~350 MB)
FROM node:18-alpine

WORKDIR /app

# ✅ Copie uniquement package*.json en premier → cache Docker optimal
# Les dépendances ne sont réinstallées que si package.json change
COPY package*.json ./

# ✅ Production uniquement : pas de devDependencies (nodemon inutile en prod)
RUN npm install --omit=dev

# ✅ Code source copié APRÈS npm install
COPY index.js ./

# ✅ Utilisateur non-root fourni par l'image officielle Node
USER node

EXPOSE 3000

# ✅ CMD corrigée : pointe vers index.js (pas dist/index.js)
CMD ["node", "index.js"]
```

### Fichier `.dockerignore`

```
node_modules/
.env
*.log
.git/
dist/
build/
npm-debug.log*
```

---

## Vérification

### Build et taille

```bash
docker build -t tp1:corrige .
docker images tp1:corrige
# IMAGE          TAG       SIZE
# tp1:corrige    latest    ~70 MB  (< 200 MB ✅)
```

### Fonctionnement

```bash
docker run --rm -p 3000:3000 tp1:corrige
# Ouvrir http://localhost:3000 → application visible ✅
```

### Utilisateur non-root

```bash
docker run --rm tp1:corrige whoami
# node  ✅
```

### Absence de secrets dans l'environnement

```bash
docker inspect tp1:corrige --format '{{range .Config.Env}}{{println .}}{{end}}' \
  | grep -iE "API_KEY|DB_PASSWORD|DB_HOST"
# (aucune sortie) ✅
```

---

## Récapitulatif des critères de réussite

| Critère | Statut | Détail |
|---------|--------|--------|
| Diagnostic (≥ 5 problèmes) | ✅ | 8 problèmes identifiés avec ligne, problème et conséquence |
| Build | ✅ | `docker build -t tp1:corrige .` fonctionne sans erreur |
| Taille < 200 MB | ✅ | ~70 MB grâce à `node:18-alpine` et `--omit=dev` |
| Pas de secrets | ✅ | Aucun `ENV` secret dans le Dockerfile ni dans l'image |
| Utilisateur `node` | ✅ | `USER node` ajouté avant `CMD` |
| Fonctionnel sur :3000 | ✅ | `CMD ["node", "index.js"]` corrigé |
| `.dockerignore` présent | ✅ | `node_modules/`, `.env`, `.git/`, logs exclus |

# TP3 — Conteneurisation de TaskFlow

## Objectif

Permettre à n'importe qui de cloner le repo et lancer toute la stack avec :

```bash
docker compose up --build
```

Aucune installation de Node, Redis ou Nginx n'est nécessaire sur la machine.

---

## Structure du projet

```
tp3/
├── backend/
│   ├── server.js         # API REST Node.js (tâches via Redis)
│   ├── package.json      # Dépendances (redis ^4.6.0)
│   └── Dockerfile        # Image node:20-alpine
├── frontend/
│   ├── index.html        # Interface web statique
│   └── Dockerfile        # Image nginx:alpine
├── docker-compose.yml    # Stack complète
├── .env.example          # Template variables d'env
└── .dockerignore         # Exclusions du contexte de build
```

---

## Étape 1 — Dockerfile backend

**`backend/Dockerfile`**

```dockerfile
FROM node:20-alpine

WORKDIR /app

# Copie package*.json avant le code → cache Docker optimal
COPY package*.json ./

# Production uniquement, sans devDependencies
RUN npm install --omit=dev

# Code source après l'installation
COPY server.js ./

# Utilisateur non-root (bonne pratique sécurité)
USER node

EXPOSE 3001

CMD ["node", "server.js"]
```

**Points validés :**

- Image `node:20-alpine` légère
- `WORKDIR /app` défini
- `package*.json` copié en premier → cache Docker exploité
- `npm install --omit=dev` → pas de devDependencies
- Code copié après les dépendances
- Port 3001 exposé
- `CMD ["node", "server.js"]` clair
- Aucun secret dans le Dockerfile
- `node_modules` non copié depuis la machine (`.dockerignore`)
- Pas d'outils système inutiles
- `USER node` → exécution non-root

---

## Étape 2 — Dockerfile frontend

**`frontend/Dockerfile`**

```dockerfile
FROM nginx:alpine

# Fichiers statiques copiés dans le dossier servi par Nginx
COPY index.html /usr/share/nginx/html/index.html

EXPOSE 80
```

**Points validés :**

- Image `nginx:alpine`
- Fichiers statiques copiés au bon endroit
- Port 80 exposé

---

## Étape 3 — `docker-compose.yml`

```yaml
version: "3.9"

services:

  frontend:
    build: ./frontend
    ports:
      - "8080:80"
    networks:
      - app_net
    depends_on:
      - backend

  backend:
    build: ./backend
    ports:
      - "${BACKEND_PORT:-3001}:3001"
    environment:
      BACKEND_PORT: 3001
      REDIS_HOST:   cache
      REDIS_PORT:   6379
    depends_on:
      - cache
    restart: on-failure
    networks:
      - app_net

  cache:
    image: redis:7-alpine
    # Pas de ports: → Redis non exposé sur l'hôte ✅
    volumes:
      - redis_data:/data
    networks:
      - app_net

volumes:
  redis_data:

networks:
  app_net:
```

**Points validés :**

- `frontend` : build `./frontend`, port `8080:80`
- `backend` : build `./backend`, port `${BACKEND_PORT:-3001}:3001`
- `cache` : image `redis:7-alpine`, **aucun port exposé**
- Variables `REDIS_HOST=cache` et `REDIS_PORT=6379` passées au backend
- Volume nommé `redis_data` pour la persistance Redis
- Réseau `app_net` commun à tous les services
- `depends_on` entre `backend → cache` et `frontend → backend`
- `restart: on-failure` sur le backend

### Vérification

```bash
docker compose up --build
docker compose ps
# NAME                COMMAND                  SERVICE    STATUS
# tp3-backend-1       "node server.js"         backend    Up
# tp3-cache-1         "docker-entrypoint.s…"   cache      Up
# tp3-frontend-1      "/docker-entrypoint.…"   frontend   Up

# Frontend
# http://localhost:8080 → interface TaskFlow ✅

# Backend health
curl http://localhost:3001/health
# {"status":"ok","redis":true} ✅

# Redis non exposé : aucun ports: sur cache dans docker-compose.yml ✅
```

---

## Étape 4 — `.env.example` et `.dockerignore`

**`.env.example`** (commité dans le repo, sans vraies valeurs sensibles)

```env
APP_ENV=local
BACKEND_PORT=3001
REDIS_HOST=cache
REDIS_PORT=6379
REDIS_PASSWORD=change-me-if-needed
```

**`.dockerignore`**

```
node_modules/
.env
*.log
.git/
dist/
build/
npm-debug.log*
```

---

## Description de l'application TaskFlow

L'API backend expose 4 routes REST :

| Méthode | Route | Description |
|---------|-------|-------------|
| `GET` | `/health` | Statut de l'API et de Redis |
| `GET` | `/tasks` | Liste toutes les tâches |
| `POST` | `/tasks` | Crée une tâche `{ title }` |
| `PATCH` | `/tasks/:id` | Toggle l'état `done` de la tâche |
| `DELETE` | `/tasks/:id` | Supprime la tâche |

Les tâches sont stockées dans Redis avec la clé `task:<timestamp>`. Le volume nommé `redis_data` assure leur persistance entre les redémarrages.

---

## Récapitulatif des critères de réussite

| Critère | Statut | Vérification |
|---------|--------|--------------|
| Commande unique | ✅ | `docker compose up --build` depuis la racine |
| Frontend | ✅ | `http://localhost:8080` affiche l'interface TaskFlow |
| Backend | ✅ | `curl http://localhost:3001/health` → `{"status":"ok","redis":true}` |
| Cache interne | ✅ | Aucun `ports:` sur le service `cache` |
| Persistance | ✅ | Volume `redis_data` déclaré, données survivent au `down` |
| Configuration | ✅ | `.env.example` présent, aucun secret en dur dans `docker-compose.yml` |
| Contexte Docker | ✅ | `.dockerignore` présent, `node_modules/` et `.env` exclus |

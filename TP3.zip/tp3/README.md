# TP3 — Conteneurisation de TaskFlow

## Objectif

Conteneuriser l'application TaskFlow de zéro : écrire les Dockerfiles et le `docker-compose.yml` pour que la stack entière se lance avec une seule commande.

## Contenu du dossier

```
tp3/
├── backend/
│   ├── server.js         # API REST Node.js (CRUD tâches via Redis)
│   ├── package.json      # Dépendances
│   └── Dockerfile        # node:20-alpine
├── frontend/
│   ├── index.html        # Interface web statique
│   └── Dockerfile        # nginx:alpine
├── docker-compose.yml    # Stack complète (frontend, backend, cache)
├── .env.example          # Template variables d'environnement
├── .dockerignore         # Exclusions du contexte de build
└── RAPPORT_TP3.md        # Explication des 4 étapes
```

## Lancer la stack

```bash
docker compose up --build
```

C'est tout. Aucune installation de Node, Redis ou Nginx requise.

## URLs

| Service | URL |
|---------|-----|
| Frontend (TaskFlow) | http://localhost:8080 |
| Backend (healthcheck) | http://localhost:3001/health |

## Variables d'environnement

```bash
cp .env.example .env
# Adapter si besoin (les valeurs par défaut fonctionnent telles quelles)
```

## Vérifications

```bash
# Les 3 services sont Up
docker compose ps

# Redis non exposé sur l'hôte (pas de ports: sur cache)
# Vérifier dans docker-compose.yml

# Persistance des tâches
docker compose down
docker compose up -d
# → Les tâches sont toujours présentes sur http://localhost:8080
```

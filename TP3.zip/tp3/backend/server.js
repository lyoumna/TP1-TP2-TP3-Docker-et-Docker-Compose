const http = require("http");
const { createClient } = require("redis");

const PORT = process.env.BACKEND_PORT || 3001;
const REDIS_HOST = process.env.REDIS_HOST || "cache";
const REDIS_PORT = process.env.REDIS_PORT || 6379;

const redis = createClient({
  socket: { host: REDIS_HOST, port: Number(REDIS_PORT) },
});

redis.on("error", (err) => console.error("Redis error:", err));

async function connectRedis() {
  await redis.connect();
  console.log(`Connecté à Redis sur ${REDIS_HOST}:${REDIS_PORT}`);
}

// ─── Helpers ──────────────────────────────────────────────────────────────
async function getAllTasks() {
  const keys = await redis.keys("task:*");
  if (keys.length === 0) return [];
  const values = await Promise.all(keys.map((k) => redis.get(k)));
  return values
    .map((v) => JSON.parse(v))
    .sort((a, b) => b.createdAt - a.createdAt);
}

function setCors(res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, DELETE, PATCH, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
}

function json(res, statusCode, data) {
  res.setHeader("Content-Type", "application/json");
  res.writeHead(statusCode);
  res.end(JSON.stringify(data));
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (chunk) => (body += chunk));
    req.on("end", () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch {
        reject(new Error("JSON invalide"));
      }
    });
  });
}

// ─── Serveur ──────────────────────────────────────────────────────────────
const server = http.createServer(async (req, res) => {
  setCors(res);

  if (req.method === "OPTIONS") {
    res.writeHead(204);
    res.end();
    return;
  }

  // GET /health
  if (req.method === "GET" && req.url === "/health") {
    json(res, 200, { status: "ok", redis: redis.isReady });
    return;
  }

  // GET /tasks
  if (req.method === "GET" && req.url === "/tasks") {
    try {
      const tasks = await getAllTasks();
      json(res, 200, tasks);
    } catch (err) {
      json(res, 500, { error: err.message });
    }
    return;
  }

  // POST /tasks
  if (req.method === "POST" && req.url === "/tasks") {
    try {
      const body = await parseBody(req);
      if (!body.title) {
        json(res, 400, { error: "title requis" });
        return;
      }
      const id = Date.now().toString();
      const task = {
        id,
        title: body.title,
        done: false,
        createdAt: Date.now(),
      };
      await redis.set(`task:${id}`, JSON.stringify(task));
      json(res, 201, task);
    } catch (err) {
      json(res, 500, { error: err.message });
    }
    return;
  }

  // PATCH /tasks/:id  (toggle done)
  const patchMatch = req.url.match(/^\/tasks\/(\d+)$/);
  if (req.method === "PATCH" && patchMatch) {
    try {
      const id = patchMatch[1];
      const raw = await redis.get(`task:${id}`);
      if (!raw) { json(res, 404, { error: "Tâche introuvable" }); return; }
      const task = JSON.parse(raw);
      task.done = !task.done;
      await redis.set(`task:${id}`, JSON.stringify(task));
      json(res, 200, task);
    } catch (err) {
      json(res, 500, { error: err.message });
    }
    return;
  }

  // DELETE /tasks/:id
  const delMatch = req.url.match(/^\/tasks\/(\d+)$/);
  if (req.method === "DELETE" && delMatch) {
    try {
      const id = delMatch[1];
      const deleted = await redis.del(`task:${id}`);
      if (!deleted) { json(res, 404, { error: "Tâche introuvable" }); return; }
      json(res, 200, { deleted: id });
    } catch (err) {
      json(res, 500, { error: err.message });
    }
    return;
  }

  json(res, 404, { error: "Route introuvable" });
});

connectRedis().then(() => {
  server.listen(PORT, () => console.log(`TaskFlow API sur le port ${PORT}`));
});
